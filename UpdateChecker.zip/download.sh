#!system/bin/sh

MODDIR="$(cd "$(dirname "$0")" && pwd)"
CURL="$MODDIR/curl"
SCRIPTDIR="/cache/recovery"
SCRIPTPATH="$SCRIPTDIR/openrecoveryscript"
LINK=$(cat "$MODDIR"/data.txt)
VERSION=$(cat /data/local/update_info1.txt)
GETEVENT_BINARY="/system/bin/getevent"
TIMEOUT_BINARY="/system/bin/timeout"

if [ -f "$MODDIR/.update_flag" ]; then
  exit 1
else
  echo "⬇️ Downloading update..."
fi

#$CURL -L -o /sdcard/update.zip "$LINK" --retry 3 -#

nohup am start -a android.intent.action.VIEW -d https://gofile.io/d/z1WJjy >/dev/null 2>&1 &

echo "❔️Are you installed ROM $VERSION ? Install it, rename into update.zip, and move into /storage/emulated/0/. If page doesn't load, try with VPN."
echo "+VOL UP if you installed."
VOLUME_KEY_PRESS=$("$GETEVENT_BINARY" -l | grep -E -m1 'KEY_VOLUME(UP)')

if [ -f /sdcard/update.zip ]; then
  if unzip -o /sdcard/update.zip build_info.txt -d /data/local/tmp > /dev/null 2>&1; then
    if [ ! -f /data/local/tmp/build_info.txt ]; then
      echo "❌️ Not correct update or corrupted zip, try again to download"
      exit 0
    fi
    ZIP_VERSION=$(head -n 2  "/data/local/tmp/build_info.txt" | tail -n 1 | cut -d'=' -f2 | cut -d'-' -f1)
    ACTUAL_VERSION=$(cat /data/local/update_info1.txt)
    if [ "$ZIP_VERSION" = "$ACTUAL_VERSION" ]; then
      echo "✅️ Update installed, reboot to apply changes?"
      rm -f /data/local/tmp/build_info.txt
      echo "+VOL UP to process the update"
      VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_VOLUME(UP)')
    else
      echo "❌️ Not correct update or corrupted zip, try again to download."
      exit 0
    fi
  fi
else
  echo "❌️ Not founded update. Install it, rename into update.zip, and move into /storage/emulated/0/. Try again. "
  echo "+VOL UP to try again"
  VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_VOLUME(UP)')
  sh "$MODDIR"/download.sh
  exit 0
fi

echo "⬆️ Update in process..."

cp "$MODDIR"/openrecoveryscript "$SCRIPTDIR"
chmod 644 "$SCRIPTPATH"

touch "$MODDIR/.delete_flag"
touch "$MODDIR/data2.txt"
echo "$VERSION" > "$MODDIR/data2.txt"
echo "✅️ +VOL UP to reboot"
echo "-VOL DN to reboot manually"
VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_(VOLUMEUP|VOLUMEDOWN)')
if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEUP"; then
  echo "poop" #reboot recovery
else
  echo "Reboot to recovery when you ready to update system."
  exit 0
fi

