#!system/bin/sh

MODDIR="$(cd "$(dirname "$0")" && pwd)"
CURRENT_VERSION=$(getprop ro.build.display.id)
CURRENT_DEVICE_MODEL=$(getprop ro.factory.model)
JSON="https://raw.githubusercontent.com/ssalemov/UpdateChecker/main/Update.json"

cmd notification post -S bigtext -t "New update founded!" "EternityROM_New_Update" "New update is available, tap on action and download update."
touch "$MODDIR/.data_gay"
exit 0

if [ ! -f /system/bin/jq ]; then
  mount -o rw,remount /
  cp "$MODDIR"/jq /system/bin/
  chmod 755 /system/bin/jq
  chown root:shell /system/bin/jq
  mount -o ro,remount /
fi

if [ ! -f /system/bin/curl ]; then
  mount -o rw,remount /
  cp "$MODDIR"/curl /system/bin/
  chmod 755 /system/bin/curl
  chown root:shell /system/bin/curl
  mount -o ro,remount /
fi

UPDATE_JSON=$(curl -sSL "$JSON")

if [ $? -ne 0 ] || [ -z $UPDATE_JSON ]; then
  exit 1
fi

AVAILABLE=$(echo "$UPDATE_JSON" | jq -r '.available // empty')
LATEST_FIRMWARE_VERSION=$(echo "$UPDATE_JSON" | jq -r '.version // empty')
MODELS=$(echo "$UPDATE_JSON" | jq -r '.Devices // empty')
DESCRIPTION=$(echo "$UPDATE_JSON" | jq -r '.Description // empty')
CURRENT_SHORT_VERSION=$(getprop ro.build.display.id | sed -n 's/.*\(v[0-9][0-9]*\(\.[0-9][0-9]*\)*\).*/\1/p')
CHANGELOG=$(echo "$UPDATE_JSON" | jq -r '.Changelog // empty')
FILE_LINK=$(echo "$UPDATE_JSON" | jq -r '.File // empty')
CHANGELOG_RAW=$(curl -sSL "$CHANGELOG")

MODEL_IS_SUPPORTED="false"
CURRENT_DEVICE_MODEL_CLEANED=$(echo "$CURRENT_DEVICE_MODEL" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')

if [[ ",${MODELS}," == *",${CURRENT_DEVICE_MODEL},"* ]]; then
    MODEL_IS_SUPPORTED="true"
fi

if [ "$AVAILABLE" = "False" ]; then
  exit 0
fi

if [ -z "$CURRENT_SHORT_VERSION" ]; then
    #echo "❌️ ERROR: Could not extract system version vX.Y from ro.build.display.id. Check format, and save log. Exit code 5"
    exit 5
fi

if [ "$MODEL_IS_SUPPORTED" = "false" ]; then
  exit 2
fi

if [ "$LATEST_FIRMWARE_VERSION" \> "$CURRENT_SHORT_VERSION" ]; then
  touch "/data/local/update_info1.txt"
  echo "$LATEST_FIRMWARE_VERSION" > /data/local/update_info1.txt
  touch "/data/local/update_info2.txt"
  echo "$CHANGELOG_RAW" >> /data/local/update_info2.txt
  touch "/data/local/update_info3.txt"
  echo "$DESCRIPTION" >> /data/local/update_info3.txt
  touch "/data/local/update_info4.txt"
  echo "$FILE_LINK" >> /data/local/update_info4.txt
  cmd notification post -S bigtext -t "New update founded!" -c "sys" -i "android.resource://android/drawable/stat_sys_download_done" "EternityROM_New_Update" "New update is available, tap on action and download update."
fi