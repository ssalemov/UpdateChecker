﻿#!/system/bin/sh

MODDIR="$(cd "$(dirname "$0")" && pwd)"
PKGS="ax.nd.faceunlock ax.nd.universalauth.xposed"

for pkg in $PKGS; do
  pm uninstall --user 0 "$pkg"
done

rm -rf /data/user/0/ax.nd.faceunlock/files/facelibs/

rm -rf "$MODDIR"

echo "✅ Module successfully deleted"