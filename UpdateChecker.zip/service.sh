#!/system/bin/sh

MODDIR="$(cd "$(dirname "$0")" && pwd)"
CURRENT_VERSION=$(getprop ro.build.display.id)

if [ ! -f "$MODDIR"/data1.txt ]; then
  touch "$MODDIR/data1.txt"
  echo "stable" > "$MODDIR/data1.txt"
fi

mkdir -p /data/cron

if [ -f "$MODDIR/.delete_flag ]; then
  exit 1
else
  echo "🔁 Deleting update files..."
fi

NEW_VERSION=$(cat /data/local/update_info1.txt)

if [ "$NEW_VERSION" > "$CURRENT_VERSION" ]; then
  cmd notification post -S bigtext -t "Update error" -c "sys" -i "android.resource://android/drawable/stat_sys_download_done" "EternityROM_Error_Update" "Oops, an error has occured when updating system! Try to update manually."
  touch "$MODDIR/.error_flag"
  logger -t OTA_PROCESS "E: System is not updated."
  exit 1
else
  touch "$MODDIR/.update_success"
fi

rm -rf /sdcard/update.zip
rm -rf "$MODDIR"/.delete_flag
rm -rf "$MODDIR"/data.txt
rm -rf "$MODDIR"/data2.txt
cp /data/local/update_info1.txt "$MODDIR"/
cp /data/local/update_info2.txt "$MODDIR"/
cp /data/local/update_info3.txt "$MODDIR"/
cp /data/local/update_info4.txt "$MODDIR"/
rm -rf /data/local/update_info1.txt
rm -rf /data/local/update_info2.txt
rm -rf /data/local/update_info3.txt
rm -rf /data/local/update_info4.txt

echo "✅️ Deleted update files"

