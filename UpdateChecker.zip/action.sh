#!system/bin/sh

MODDIR="$(cd "$(dirname "$0")" && pwd)"
JQ="jq"
CURL="curl"
CURRENT_VERSION=$(getprop ro.build.display.id)
CURRENT_DEVICE_MODEL=$(getprop ro.factory.model)
JSON="https://raw.githubusercontent.com/ssalemov/UpdateChecker/main/Update.json"
SETTING=false

if [ -f "$MODDIR"/data1.txt ]; then
  STABLE_OR_BETA=$(cat "$MODDIR"/data1.txt)
fi

echo "Check for updates: +VOL UP"
echo "Settings: -VOL DN"
echo "Last update: • POWER"
GETEVENT_BINARY="/system/bin/getevent"
TIMEOUT_BINARY="/system/bin/timeout"
VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_(VOLUMEUP|VOLUMEDOWN|POWER)')

if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEDOWN"; then
  sh "$MODDIR"/settings.sh
  SETTING=true
fi

if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_POWER"; then
  sh "$MODDIR"/last_update.sh
  exit 0
fi

if [ "$SETTING" = "false" ]; then
if [ "$STABLE_OR_BETA" = "stable" ]; then
if [ ! -f /system/bin/jq ]; then
  mount -o rw,remount /
  cp "$MODDIR"/jq /system/bin/
  chmod 755 /system/bin/jq
  chown root:shell /system/bin/jq
  mount -o ro,remount /
fi

if [ ! -f /system/bin/curl ]; then
  mount -o rw,remount /
  cp "$MODDIR"/curl /system/bin/
  chmod 755 /system/bin/curl
  chown root:shell /system/bin/curl
  mount -o ro,remount /
fi

chmod +x "$MODDIR"/curl
chmod +x "$MODDIR"/jq

if [ -f "$MODDIR"/.error_flag ]; then
  echo " "
  echo " ⚠️ SYSTEM UPDATE FAILED!! ⚠️ "
  echo " "
  echo "⚠️ System update failed. Please, try again to update system or update manually in TWRP"
  echo "+VOL UP: reboot to TWRP and you need flash update.zip in /storage/emulated/0/; more secure"
  echo "-VOL DN: update via internet and try to update system; has an risk"
  VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_(VOLUMEUP|VOLUMEDOWN)')
  if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEUP"; then
    reboot recovery
  fi
  if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEDOWN"; then
    sh "$MODDIR"/download.sh
    exit 0
  fi
fi

if [ -f /data/local/update_info1.txt ]; then
  STROKE_ONE=$(cat /data/local/update_info1.txt)
  STROKE_TWO=$(cat /data/local/update_info2.txt)
  STROKE_THREE=$(cat /data/local/update_info3.txt)
  STROKE_FOUR=$(cat /data/local/update_info4.txt)
  FOUND_UPDATE="true"
  echo "New stable update is now available!"
  echo "EternityROM $STROKE_ONE"
  echo "$STROKE_THREE"
  echo " "
  echo " "
  echo "Changelogs:"
  echo "$STROKE_TWO"
  echo " "
  echo " "
  echo "Download update now?"
  echo " "
  echo "+VOL UP to download"
  GETEVENT_BINARY="/system/bin/getevent"
  TIMEOUT_BINARY="/system/bin/timeout"
  VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_VOLUME(UP)')
  touch "$MODDIR/data.txt"
  echo "$STROKE_FOUR" > "$MODDIR"/data.txt
  sh "$MODDIR"/download.sh
  exit 0
else
  FOUND_UPDATE="false"
fi

check_internet_connection() {
    echo "🌐 Checking internet connection..."
    if $CURL --head --silent --fail --max-time 10 http://www.google.com > /dev/null; then
        echo "✅ Internet connection is active."
        return 0
    else
        echo "❌ No internet connection available."
        return 1
    fi
}

if ! check_internet_connection; then
  exit 1
fi

echo "🔁 Checking for updates..."
UPDATE_JSON=$($CURL -sSL "$JSON")

if [ $? -ne 0 ] || [ -z $UPDATE_JSON ]; then
  echo "❌️ Error 16. Cannot download sctipt compare update"
  exit 16
fi

AVAILABLE=$(echo "$UPDATE_JSON" | $JQ -r '.available // empty')
LATEST_FIRMWARE_VERSION=$(echo "$UPDATE_JSON" | $JQ -r '.version // empty')
MODELS=$(echo "$UPDATE_JSON" | $JQ -r '.Devices // empty')
DESCRIPTION=$(echo "$UPDATE_JSON" | $JQ -r '.Description // empty')
CURRENT_SHORT_VERSION=$(getprop ro.build.display.id | sed -n 's/.*\(v[0-9][0-9]*\(\.[0-9][0-9]*\)*\).*/\1/p')
CHANGELOG=$(echo "$UPDATE_JSON" | $JQ -r '.Changelog // empty')
FILE_LINK=$(echo "$UPDATE_JSON" | $JQ -r '.File // empty')
CHANGELOG_RAW=$($CURL -sSL "$CHANGELOG")

MODEL_IS_SUPPORTED="false"
CURRENT_DEVICE_MODEL_CLEANED=$(echo "$CURRENT_DEVICE_MODEL" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')
echo "DEBUG: Cleaned current device model: $CURRENT_DEVICE_MODEL_CLEANED" > /dev/kmsg

if [[ ",${MODELS}," == *",${CURRENT_DEVICE_MODEL},"* ]]; then
    MODEL_IS_SUPPORTED="true"
fi

if [ ! "$AVAILABLE" = "True" ]; then
  echo "❌️ No new update founded."
  exit 0
fi

if [ -z "$CURRENT_SHORT_VERSION" ]; then
    echo "❌️ ERROR: Could not extract system version vX.Y from ro.build.display.id. Check format, and save log. Exit code 5"
    exit 5
fi

if [ "$MODEL_IS_SUPPORTED" = "false" ]; then
  echo "Current model is not supported 😞. Your model is $CURRENT_DEVICE_MODEL"
  exit 2
fi

if [ "$LATEST_FIRMWARE_VERSION" \> "$CURRENT_SHORT_VERSION" ]; then
  touch "/data/local/update_info1.txt"
  echo "$LATEST_FIRMWARE_VERSION" > /data/local/update_info1.txt
  touch "/data/local/update_info2.txt"
  echo "$CHANGELOG_RAW" >> /data/local/update_info2.txt
  touch "/data/local/update_info3.txt"
  echo "$DESCRIPTION" >> /data/local/update_info3.txt
  touch "/data/local/update_info4.txt"
  echo "$FILE_LINK" >> /data/local/update_info4.txt
  echo " "
  echo "____________________________________"
  echo "New stable update is now available!"
  echo "EternityROM $LATEST_FIRMWARE_VERSION"
  echo "$DESCRIPTION"
  echo " "
  echo " "
  echo "Changelogs:"
  echo "$CHANGELOG_RAW"
  echo " "
  echo " "
  echo "Download update now?"
  echo " "
  echo "+VOL UP to download"
  GETEVENT_BINARY="/system/bin/getevent"
  TIMEOUT_BINARY="/system/bin/timeout"
  VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_VOLUME(UP)')
  touch "$MODDIR"/data.txt
  echo "$FILE_LINK" > "$MODDIR"/data.txt
  sh "$MODDIR"/download.sh
else
  echo "❌️ No new update founded."
  exit 0
fi
else
echo " ⚠️ Module is corrupted. Reinstall again."
exit 4
fi
fi
