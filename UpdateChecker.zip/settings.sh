#!/system/bin/sh

MODDIR="$(cd "$(dirname "$0")" && pwd)"
INDEX=1
LIST_1="set when check for updates"
LIST_2="about this project"
LIST_3="check for beta/stable updates"
LIST_SMART="LIST_$INDEX"
STABLE_OR_BETA=$(cat "$MODDIR"/data1.txt)

while true; do
  if [ "$INDEX" = "4" ]; then
    INDEX=1
  fi

  if [ "$INDEX" = "1" ]; then
    LIST_CORRECT="$LIST_1"
  fi

  if [ "$INDEX" = "2" ]; then
    LIST_CORRECT="$LIST_2"
  fi
  
  if [ "$INDEX" = "3" ]; then
    LIST_CORRECT=$LIST_3
  fi

  echo "+VOL UP to $LIST_CORRECT"
  echo "-VOL DN to list down"
  echo "• POWER to exit"
  GETEVENT_BINARY="/system/bin/getevent"
  TIMEOUT_BINARY="/system/bin/timeout"
  VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_(VOLUMEUP|VOLUMEDOWN|POWER)')
  
  if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_POWER"; then
    exit 0
  fi

  if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEDOWN"; then
    INDEX=$((INDEX + 1))
  fi

  if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEUP"; then
    if [ "$INDEX" = "1" ]; then
      echo "When you need to check for updates?"
      echo "(DEFAULT) On boot"
    fi
    if [ "$INDEX" = "2" ]; then
      echo "About this project"
      echo "Created by @krutoyerali"
      echo " "
      echo "Open-source module for improving OTA-Updates to Custom ROM."
      echo "• POWER to exit"
      VOLUME_KEY_PRESS=$("$TIMEOUT_BINARY" 180 "$GETEVENT_BINARY" -l | grep -E -m1 'KEY_POWER')
      exit 0
    fi
    if [ "$INDEX" = "3" ]; then
      echo "Check for $STABLE_OR_BETA updates"
      echo "+VOL UP to set check ONLY stable updates"
      echo "-VOL DN to set check for stable and beta updates (coming in v1.1)"
      echo "• POWER to exit"
      VOLUME_KEY_PRESS=$("$GETEVENT_BINARY" -l | grep -E -m1 'KEY_(VOLUMEUP|VOLUMEDOWN|POWER)')
      if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_VOLUMEUP"; then
        echo "stable" > "$MODDIR/data1.txt"
        echo "✅️ Setted."
        exit 0
      fi
      if echo "$VOLUME_KEY_PRESS" | grep -q "KEY_POWER"; then
        exit 0
      fi
    fi
  fi
done